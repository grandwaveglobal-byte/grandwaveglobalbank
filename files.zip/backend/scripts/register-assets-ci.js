#!/usr/bin/env node
/**
 * register-assets-ci.js
 *
 * CI helper script to register generated assets into the database after
 * assets have been generated and uploaded to S3 (or available locally).
 *
 * Behavior:
 * - Scans backend/public/assets for texture files (*.webp) and matching normal maps (*-normal.png).
 * - For each texture file, ensures there is an Asset record (by name+variant).
 *   - If no Asset exists: create Asset + initial AssetVersion (v1).
 *   - If Asset exists and texture differs from latest version, create a new AssetVersion.
 *
 * Usage (CI):
 *  - Set env DATABASE_URL (Prisma), USE_S3 (true/false), AWS_S3_BUCKET (if USE_S3)
 *  - Run: node backend/scripts/register-assets-ci.js
 *
 * Notes:
 *  - This script uses Prisma Client. Ensure `npx prisma generate` has been run in CI.
 *  - When USE_S3=true the script stores S3 keys as the texturePath (e.g. assets/<file.webp>).
 *  - When local, it stores the public path (/assets/<file.webp>).
 */

const fs = require('fs');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function main() {
  const USE_S3 = process.env.USE_S3 === 'true';
  const S3_BUCKET = process.env.AWS_S3_BUCKET;
  const publicAssetsDir = path.join(process.cwd(), 'public', 'assets');

  if (!fs.existsSync(publicAssetsDir)) {
    console.log('No assets dir found at', publicAssetsDir);
    return;
  }

  const files = fs.readdirSync(publicAssetsDir);
  // find webp texture files
  const textures = files.filter(f => /\.webp$/i.test(f));
  console.log(`Found ${textures.length} texture(s) to register.`);

  for (const texFile of textures) {
    try {
      const base = path.parse(texFile).name; // e.g., card-rose
      // try to find a normal map: base-normal.png
      const normalCandidate = `${base}-normal.png`;
      const hasNormal = files.includes(normalCandidate);

      const texturePath = USE_S3 ? `assets/${texFile}` : `/assets/${texFile}`;
      const normalPath = hasNormal ? (USE_S3 ? `assets/${normalCandidate}` : `/assets/${normalCandidate}`) : null;

      // Heuristic for name/variant: if name contains '-' treat last segment as variant
      let name = base;
      let variant = null;
      const parts = base.split('-');
      if (parts.length > 1) {
        variant = parts[parts.length - 1];
        name = parts.slice(0, -1).join('-');
      }

      // See if an asset with same name+variant exists
      const existing = await prisma.asset.findFirst({
        where: {
          name: name,
          variant: variant
        },
        include: { versions: { orderBy: { versionNumber: 'desc' } } }
      });

      if (!existing) {
        // create new Asset + initial version (v1)
        const asset = await prisma.asset.create({
          data: {
            name,
            variant,
            texturePath,
            normalPath,
            originalPath: texturePath,
            storage: USE_S3 ? 's3' : 'local'
          }
        });
        await prisma.assetVersion.create({
          data: {
            assetId: asset.id,
            versionNumber: 1,
            texturePath,
            normalPath,
            notes: 'Initial import from CI assets generator'
          }
        });
        console.log(`Created asset '${name}' variant='${variant}' with texture ${texturePath}`);
      } else {
        // compare with latest version
        const latest = existing.versions && existing.versions.length ? existing.versions[0] : null;
        const latestTexture = latest ? latest.texturePath : null;
        if (latestTexture !== texturePath) {
          // create a new version with incremented version number
          const highest = existing.versions.reduce((m, v) => Math.max(m, v.versionNumber), 0);
          const v = await prisma.assetVersion.create({
            data: {
              assetId: existing.id,
              versionNumber: highest + 1,
              texturePath,
              normalPath,
              notes: 'Auto-registered by CI assets pipeline'
            }
          });
          // update asset pointer to new texture
          await prisma.asset.update({ where: { id: existing.id }, data: { texturePath, normalPath } });
          console.log(`Created new version v${v.versionNumber} for asset '${existing.name}' (id=${existing.id})`);
        } else {
          console.log(`Asset '${existing.name}' already up-to-date (texture=${texturePath})`);
        }
      }
    } catch (err) {
      console.error('Error registering asset', texFile, err);
    }
  }
}

main()
  .catch(err => {
    console.error('Fatal error', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });