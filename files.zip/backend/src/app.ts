import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import csurf from 'csurf';
import rateLimit from 'express-rate-limit';
import path from 'path';
import authRoutes from './routes/auth';
import accountRoutes from './routes/accounts';
import cardRoutes from './routes/cards';
import assetsRoutes from './routes/assets';
import kycRoutes from './routes/kyc';
import adminRoutes from './routes/admin';

const app = express();

// Security headers
app.use(helmet({
  contentSecurityPolicy: false // adjust CSP in production for scripts and cdn usage
}));

// Logging
app.use(morgan('combined'));

// Body parsing + cookies
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Serve static assets created by asset pipeline
app.use('/assets', express.static(path.join(process.cwd(), 'public', 'assets'), { maxAge: '7d' }));

// CORS: restrict to frontend origin
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';
app.use(cors({
  origin: FRONTEND_ORIGIN,
  credentials: true,
  allowedHeaders: ['Content-Type', 'X-CSRF-Token']
}));

// Rate limiter for auth endpoints
const authLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 15,
  standardHeaders: true,
  legacyHeaders: false
});

// Public routes
app.use('/api/auth', authLimiter, authRoutes);

// CSRF endpoint (cookie-based). Frontend must fetch this token and send X-CSRF-Token header.
const csrfProtection = csurf({ cookie: true });
app.get('/api/csrf-token', csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

// API routes (protected by auth middleware within route files)
app.use('/api/accounts', accountRoutes);
app.use('/api/cards', cardRoutes);
app.use('/api/assets', assetsRoutes);
app.use('/api/kyc', kycRoutes);
app.use('/api/admin', adminRoutes);

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

export default app;