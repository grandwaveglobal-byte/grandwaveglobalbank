// small helper to build notification messages when assets/versions are created
import { sendTelegramMessage } from '../services/telegramService';
import { getPresignedGetUrl } from '../services/s3Service';

export async function notifyNewAsset(asset: any) {
  try {
    const useS3 = process.env.USE_S3 === 'true';
    let textureUrl = asset.texturePath;
    if (useS3) {
      try {
        textureUrl = await getPresignedGetUrl(asset.texturePath);
      } catch {
        textureUrl = `s3://${process.env.AWS_S3_BUCKET}/${asset.texturePath}`;
      }
    }
    const msg = `<b>New asset uploaded</b>\nName: ${asset.name}\nVariant: ${asset.variant || '—'}\nTexture: ${textureUrl}`;
    await sendTelegramMessage(process.env.TELEGRAM_SUPPORT_CHAT_ID, msg);
  } catch (err) {
    console.error('notifyNewAsset failed', err);
  }
}

export async function notifyNewVersion(version: any, assetName: string) {
  try {
    const useS3 = process.env.USE_S3 === 'true';
    let textureUrl = version.texturePath;
    if (useS3) {
      try {
        textureUrl = await getPresignedGetUrl(version.texturePath);
      } catch {
        textureUrl = `s3://${process.env.AWS_S3_BUCKET}/${version.texturePath}`;
      }
    }
    const msg = `<b>Asset version published</b>\nAsset: ${assetName}\nVersion: v${version.versionNumber}\nPreview: ${textureUrl}`;
    await sendTelegramMessage(process.env.TELEGRAM_SUPPORT_CHAT_ID, msg);
  } catch (err) {
    console.error('notifyNewVersion failed', err);
  }
}