import { Request, Response, NextFunction } from 'express';
import prisma from '../prismaClient';
import path from 'path';
import fs from 'fs';
import sharp from 'sharp';
import { uploadBufferToS3, getPresignedGetUrl } from '../services/s3Service';
import { sendTelegramMessage } from '../services/telegramService';

const USE_S3 = process.env.USE_S3 === 'true';

/* ... keep existing functions above unchanged ... */

/**
 * Create a new version for an existing asset (admin).
 * Accepts optional upload of new texture/normal (multipart) — otherwise copies current texture path.
 */
export async function createAssetVersionHandler(req: Request & { user?: any, file?: any, files?: any }, res: Response, next: NextFunction) {
  try {
    const uploader = req.user;
    if (!uploader) return res.status(401).json({ message: 'Unauthorized' });

    const assetId = Number(req.params.id);
    const asset = await prisma.asset.findUnique({ where: { id: assetId }, include: { versions: true } });
    if (!asset) return res.status(404).json({ message: 'Asset not found' });

    // Determine next version number
    const highest = asset.versions.reduce((max, v) => Math.max(max, v.versionNumber), 0);
    const vnum = highest + 1;

    // optionally accept uploaded new files
    const textureUpload = (req as any).files?.file?.[0];
    const normalUpload = (req as any).files?.normal?.[0];
    let texturePathFinal = asset.texturePath;
    let normalPathFinal = asset.normalPath || null;

    const publicAssetsDir = path.join(process.cwd(), 'public', 'assets');

    if (textureUpload) {
      const textureSrc = textureUpload.path;
      const base = path.parse(textureUpload.filename).name;
      const webpName = `${base}.webp`;
      const webpLocal = path.join(publicAssetsDir, webpName);
      await sharp(textureSrc).resize(2000, null, { withoutEnlargement: true }).webp({ quality: 86 }).toFile(webpLocal);
      if (USE_S3) {
        const buf = fs.readFileSync(webpLocal);
        await uploadBufferToS3(buf, `assets/${webpName}`, 'image/webp');
        texturePathFinal = `assets/${webpName}`;
        fs.unlinkSync(webpLocal);
      } else {
        texturePathFinal = `/assets/${webpName}`;
      }
    }

    if (normalUpload) {
      const normalSrc = normalUpload.path;
      const normalName = path.parse(normalUpload.filename).name;
      const normalOut = `${normalName}.png`;
      const normalLocal = path.join(publicAssetsDir, normalOut);
      await sharp(normalSrc).resize(1024, 1024, { withoutEnlargement: true }).png().toFile(normalLocal);
      if (USE_S3) {
        const buf = fs.readFileSync(normalLocal);
        await uploadBufferToS3(buf, `assets/${normalOut}`, 'image/png');
        normalPathFinal = `assets/${normalOut}`;
        fs.unlinkSync(normalLocal);
      } else {
        normalPathFinal = `/assets/${normalOut}`;
      }
    }

    // create version record
    const ver = await prisma.assetVersion.create({
      data: {
        assetId,
        versionNumber: vnum,
        texturePath: texturePathFinal,
        normalPath: normalPathFinal,
        createdById: uploader.id,
        notes: req.body.notes || null
      }
    });

    // update current asset pointer
    await prisma.asset.update({
      where: { id: assetId },
      data: { texturePath: texturePathFinal, normalPath: normalPathFinal }
    });

    // Send Telegram notification (if configured)
    try {
      let previewUrl = texturePathFinal;
      if (USE_S3) {
        // generate short presigned url
        previewUrl = await getPresignedGetUrl(texturePathFinal, 3600);
      }
      const text = `📣 New asset version published\nAsset: ${asset.name} ${asset.variant ? `(${asset.variant})` : ''}\nVersion: v${vnum}\nBy: ${uploader.email}\nPreview: ${previewUrl}`;
      await sendTelegramMessage(undefined, text);
    } catch (tErr) {
      console.warn('Telegram notification failed', tErr);
    }

    return res.json({ success: true, version: ver });
  } catch (err) {
    return next(err);
  }
}