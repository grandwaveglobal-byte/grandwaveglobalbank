import { Router } from 'express';
import csurf from 'csurf';
import { authMiddleware } from '../security/authMiddleware';
import { adminMiddleware } from '../security/adminMiddleware';
import {
  uploadAssetHandler,
  listAssetsHandler,
  presignAssetHandler,
  createAssetVersionHandler,
  listAssetVersionsHandler,
  rollbackAssetVersionHandler
} from '../controllers/assetController';
import { uploadLocal } from '../middleware/upload';

const router = Router();
const csrfProtection = csurf({ cookie: true });

// Public list
router.get('/', listAssetsHandler);

// Presign (public access to presigned URLs)
router.get('/:id/presign', presignAssetHandler);

// Admin upload (initial)
router.post(
  '/upload',
  authMiddleware,
  adminMiddleware,
  uploadLocal.fields([{ name: 'file', maxCount: 1 }, { name: 'normal', maxCount: 1 }]),
  csrfProtection,
  uploadAssetHandler
);

// Create a new version for an asset (admin)
router.post(
  '/:id/version',
  authMiddleware,
  adminMiddleware,
  uploadLocal.fields([{ name: 'file', maxCount: 1 }, { name: 'normal', maxCount: 1 }]),
  csrfProtection,
  createAssetVersionHandler
);

// List versions
router.get('/:id/versions', authMiddleware, adminMiddleware, csrfProtection, listAssetVersionsHandler);

// Rollback
router.post('/:id/versions/:versionId/rollback', authMiddleware, adminMiddleware, csrfProtection, rollbackAssetVersionHandler);

export default router;