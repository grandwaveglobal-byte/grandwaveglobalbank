import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import fs from 'fs';

const REGION = process.env.AWS_REGION;
const BUCKET = process.env.AWS_S3_BUCKET;

if (!REGION || !BUCKET) {
  // In many dev setups these may be undefined — functions will error if used without config.
  console.warn('[s3Service] AWS_REGION or AWS_S3_BUCKET not configured.');
}

const s3 = new S3Client({
  region: REGION,
  credentials:
    process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY
      ? {
          accessKeyId: process.env.AWS_ACCESS_KEY_ID,
          secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
        }
      : undefined
});

/**
 * Upload a buffer to S3 under the given key.
 * Returns the s3 key (path) or throws.
 */
export async function uploadBufferToS3(buffer: Buffer, key: string, contentType: string) {
  if (!BUCKET) throw new Error('S3 bucket not configured');
  const cmd = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    Body: buffer,
    ContentType: contentType,
    ACL: 'private'
  });
  await s3.send(cmd);
  return `s3://${BUCKET}/${key}`;
}

/**
 * Upload a local file to S3.
 */
export async function uploadFileToS3(localPath: string, key: string, contentType: string) {
  const buffer = fs.readFileSync(localPath);
  return uploadBufferToS3(buffer, key, contentType);
}

/**
 * Generate a presigned GET URL for the object key.
 * expiresSeconds: how long url is valid (default 15 minutes)
 */
export async function getPresignedGetUrl(key: string, expiresSeconds = 900) {
  if (!BUCKET) throw new Error('S3 bucket not configured');
  const cmd = new GetObjectCommand({ Bucket: BUCKET, Key: key });
  return getSignedUrl(s3, cmd, { expiresIn: expiresSeconds });
}