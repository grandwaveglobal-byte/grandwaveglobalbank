import fetch from 'node-fetch';

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const SUPPORT_CHAT = process.env.TELEGRAM_SUPPORT_CHAT_ID || '';

export async function sendTelegramMessage(chatId: string | undefined, text: string) {
  const target = chatId || SUPPORT_CHAT;
  if (!BOT_TOKEN || !target) {
    console.log('[telegram] not configured — skipping:', text.substring(0, 200));
    return;
  }

  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  try {
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: target, text, parse_mode: 'HTML' })
    });
  } catch (err) {
    console.error('Telegram send error', err);
  }
}