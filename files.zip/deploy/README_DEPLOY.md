Production deployment guide (quick reference)

Prerequisites:
- A Linux server with Docker & Docker Compose installed (Ubuntu 22.04+ recommended).
- Domain name pointing to the server's public IP (A record).
- GitHub repository with the code and GitHub Actions secrets configured.

1) Prepare server (one-time)
- Create a deploy user (e.g., deploy) and allow SSH access via key.
- Install Docker & Docker Compose, certbot (if using Let's Encrypt on host).
- Create directory for app: /opt/grandwave
- Place docker-compose.prod.yml and deploy/nginx conf into /opt/grandwave.
- Create folder structure:
  mkdir -p /opt/grandwave/{backend,frontend,deploy}/nginx/certs

2) Populate backend .env
- Copy backend/.env.production.example -> /opt/grandwave/backend/.env and fill in secrets (DATABASE_URL, JWT_SECRET, etc).
- Ensure TELEGRAM_BOT_TOKEN and TELEGRAM_SUPPORT_CHAT_ID are set for notifications.

3) TLS certificates (Let's Encrypt)
Option A (recommended): run certbot on host and place certs in deploy/nginx/certs; configure grandwave.conf ssl_certificate path accordingly.
Option B: use Traefik/ACME in docker-compose (more advanced).

4) Build & run (manual)
- Option 1: use local images built via GitHub Actions (see CI file) and push to registry, then update docker-compose to use those images and run:
  docker compose -f docker-compose.prod.yml pull
  docker compose -f docker-compose.prod.yml up -d

- Option 2: build locally:
  docker build -t grandwave/backend:latest -f backend/Dockerfile .
  docker build -t grandwave/frontend:latest -f frontend/Dockerfile .
  Edit docker-compose.prod.yml to reference these tags and run:
  docker compose -f docker-compose.prod.yml up -d

5) Run DB migrations & seed
- Exec into backend container and run:
  docker compose -f docker-compose.prod.yml exec backend npx prisma migrate deploy
  docker compose -f docker-compose.prod.yml exec backend node dist/prisma/seed.js
  docker compose -f docker-compose.prod.yml exec backend node dist/scripts/create-admin.js admin@grandwave.test StrongAdminPass!

6) CI/CD with GitHub Actions
- Use the provided .github/workflows/deploy-prod.yml to build, push images to GitHub Container Registry (or Docker Hub), and SSH to the server to perform docker compose pull & up -d.
- Add GitHub Secrets required by workflow:
  - REGISTRY_USERNAME, REGISTRY_PASSWORD (or GHCR token)
  - SERVER_SSH_KEY (private key with access to deploy user)
  - SERVER_HOST, SERVER_USER, SERVER_APP_DIR (/opt/grandwave)
  - AWS_*, DATABASE_URL, TELEGRAM_*, JWT_SECRET etc as needed.

7) Health checks & monitoring
- Monitor logs:
  docker compose -f docker-compose.prod.yml logs -f backend
- Add monitoring/alerts (Prometheus/Grafana) and centralized logs (ELK/Loki) for production.

If you want I can:
- Provide an opinionated deploy GitHub Action (I included template) with exact variables for GHCR push + SSH remote deploy.
- Add Traefik + Let's Encrypt config in docker-compose so TLS issuance occurs automatically by container.