Quick deploy commands (copy & run)

1) Prepare local production env file (do NOT commit)
   cp backend/.env.production.example backend/.env.production
   # edit backend/.env.production with secure values: DATABASE_URL, JWT_SECRET, AWS_*, SMTP_*, TELEGRAM_*, etc.

2) Upload GitHub secrets (requires gh CLI)
   chmod +x deploy/gh-set-secrets.sh
   ./deploy/gh-set-secrets.sh backend/.env.production your-org/your-repo

3) Provision server (Ansible) or run manual steps:
   # Ansible
   ansible-playbook -i ansible/hosts.ini ansible/provision-playbook.yml --private-key ~/.ssh/id_rsa

   # OR manual (on server)
   sudo apt update && sudo apt install -y apt-transport-https ca-certificates curl
   curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
   echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list
   sudo apt update
   sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
   sudo usermod -aG docker $USER
   mkdir -p /opt/grandwave/{backend,frontend,deploy/nginx/certs,public}
   sudo chown -R $USER:$USER /opt/grandwave

4) Deploy (local script)
   chmod +x deploy/deploy-all.sh
   ./deploy/deploy-all.sh
   # follow prompts: github repo, env path, server SSH, registry (if building locally), etc.

5) Request TLS (if using host certbot)
   scp deploy/setup-certbot.sh deploy@your.server.ip:/opt/grandwave/deploy/
   ssh deploy@your.server.ip "chmod +x /opt/grandwave/deploy/setup-certbot.sh && sudo /opt/grandwave/deploy/setup-certbot.sh your.domain.com you@your-email.com /opt/grandwave"
   ssh deploy@your.server.ip "docker compose -f /opt/grandwave/docker-compose.prod.yml restart nginx"

6) Verify:
   curl -k https://your.domain.com/api/health
   Visit https://your.domain.com in browser