#!/usr/bin/env bash
# deploy-all.sh
# Orchestrates GH secrets upload -> (optional) local image build/push -> copy deploy files -> remote deploy -> migrations -> optional certbot
# WARNING: Keep production env file secret. Ensure gh CLI is authenticated and you have SSH access to target server.
set -euo pipefail

# Prompts
read -rp "GitHub repo (owner/repo) e.g. your-org/grandwave: " GITHUB_REPO
read -rp "Path to local production env file (e.g. backend/.env.production): " ENV_FILE
read -rp "Server SSH (user@host) e.g. deploy@1.2.3.4: " SERVER_SSH
read -rp "Server app directory (default: /opt/grandwave): " SERVER_APP_DIR
SERVER_APP_DIR=${SERVER_APP_DIR:-/opt/grandwave}
read -rp "Use local Docker build & push? (y/N): " DO_BUILD
read -rp "Registry prefix (e.g. ghcr.io/your-org) or leave blank to use CI build: " REGISTRY

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Env file not found: $ENV_FILE"
  exit 1
fi

# 1) Upload secrets to GitHub
if command -v gh >/dev/null 2>&1; then
  read -rp "Upload secrets from $ENV_FILE to GitHub repo $GITHUB_REPO? (y/N): " UPLOAD_SECRETS
  if [[ "$UPLOAD_SECRETS" =~ ^[Yy]$ ]]; then
    echo "Uploading secrets..."
    grep -E '^[A-Z0-9_]+=.*' "$ENV_FILE" | while IFS='=' read -r KEY VAL; do
      if [[ -z "$KEY" || "$KEY" =~ ^# ]]; then continue; fi
      KEY=$(echo "$KEY" | xargs)
      VAL=$(echo "$VAL" | sed -e 's/^ *//g' -e 's/ *$//g')
      if [[ -z "$VAL" ]]; then echo "Skipping $KEY (empty)"; continue; fi
      echo "Setting secret: $KEY"
      gh secret set "$KEY" --repo "$GITHUB_REPO" --body "$VAL"
    done
    echo "Secrets uploaded."
  fi
else
  echo "gh CLI not found — skipping GitHub secrets upload. Install gh and authenticate (gh auth login)."
fi

# 2) Optional local build & push
if [[ "$DO_BUILD" =~ ^[Yy] ]]; then
  read -rp "Registry username (leave blank to skip docker login): " REG_USER
  if [[ -n "$REG_USER" ]]; then
    read -srp "Registry password: " REG_PASS
    echo
    echo "$REG_PASS" | docker login "${REGISTRY%%/*}" --username "$REG_USER" --password-stdin
  fi
  BACKEND_TAG="${REGISTRY:+$REGISTRY/}grandwave-backend:latest"
  FRONTEND_TAG="${REGISTRY:+$REGISTRY/}grandwave-frontend:latest"
  echo "Building backend -> $BACKEND_TAG"
  docker build -t "$BACKEND_TAG" -f backend/Dockerfile backend
  docker push "$BACKEND_TAG"
  echo "Building frontend -> $FRONTEND_TAG"
  docker build -t "$FRONTEND_TAG" -f frontend/Dockerfile frontend
  docker push "$FRONTEND_TAG"
fi

# 3) Copy deploy bundle to server
TMP_TAR="/tmp/grandwave_deploy_$(date +%s).tgz"
tar -czf "$TMP_TAR" docker-compose.prod.yml deploy/ || true
echo "Uploading deployment bundle to $SERVER_SSH:$SERVER_APP_DIR"
ssh "$SERVER_SSH" "mkdir -p '$SERVER_APP_DIR' && chown -R $(whoami) '$SERVER_APP_DIR'" || true
scp "$TMP_TAR" "$SERVER_SSH":"$SERVER_APP_DIR"/
rm -f "$TMP_TAR"

# 4) Remote extract & deploy
ssh "$SERVER_SSH" bash -s <<EOF
set -e
APP_DIR="$SERVER_APP_DIR"
cd "\$APP_DIR"
tar -xzf "$(basename "$TMP_TAR")" || true
# Pull and start containers
docker compose -f docker-compose.prod.yml pull || true
docker compose -f docker-compose.prod.yml up -d --remove-orphans
sleep 6
# Run migrations & seed (best-effort)
docker compose -f docker-compose.prod.yml exec -T backend npx prisma migrate deploy || true
docker compose -f docker-compose.prod.yml exec -T backend node dist/prisma/seed.js || true
# Create admin (best-effort)
docker compose -f docker-compose.prod.yml exec -T backend node dist/scripts/create-admin.js admin@grandwave.test StrongAdminPass! || true
EOF

echo "Remote deploy complete. Check server logs and confirm site availability."
echo "Next steps: request TLS (deploy/setup-certbot.sh) or use Traefik (deploy/traefik) for ACME."