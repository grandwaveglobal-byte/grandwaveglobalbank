#!/usr/bin/env bash
# Usage: ./deploy/gh-set-secrets.sh /path/to/backend/.env.production owner/repo
set -e
ENV_FILE="${1:?env file required}"
REPO="${2:?owner/repo required}"
if ! command -v gh >/dev/null 2>&1; then
  echo "gh CLI not found. Install and authenticate (gh auth login)."
  exit 1
fi
echo "Uploading secrets from $ENV_FILE to $REPO"
grep -E '^[A-Z0-9_]+=.*' "$ENV_FILE" | while IFS='=' read -r KEY VAL; do
  if [[ -z "$KEY" || "$KEY" =~ ^# ]]; then continue; fi
  KEY=$(echo "$KEY" | xargs)
  VAL=$(echo "$VAL" | sed -e 's/^ *//g' -e 's/ *$//g')
  if [[ -z "$VAL" ]]; then echo "Skipping $KEY (empty)"; continue; fi
  echo "Setting secret: $KEY"
  gh secret set "$KEY" --repo "$REPO" --body "$VAL"
done
echo "All secrets set."