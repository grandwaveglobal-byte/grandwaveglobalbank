#!/usr/bin/env bash
# Run on host to request Let's Encrypt certs via webroot. Usage:
# sudo ./setup-certbot.sh your.domain.com you@your-email.com /opt/grandwave
set -e
DOMAIN="$1"
EMAIL="$2"
APP_DIR="${3:-/opt/grandwave}"
WEBROOT="$APP_DIR/deploy/nginx/www"
CERT_DIR="$APP_DIR/deploy/nginx/certs"
mkdir -p "$WEBROOT" "$CERT_DIR"
echo "Ensure port 80 is available. Running certbot..."
certbot certonly --non-interactive --agree-tos --email "$EMAIL" --webroot -w "$WEBROOT" -d "$DOMAIN"
LE_DIR="/etc/letsencrypt/live/$DOMAIN"
cp -L "$LE_DIR/fullchain.pem" "$CERT_DIR/fullchain.pem"
cp -L "$LE_DIR/privkey.pem" "$CERT_DIR/privkey.pem"
chmod 600 "$CERT_DIR/privkey.pem"
echo "Certs copied to $CERT_DIR. Restart nginx container after this step."