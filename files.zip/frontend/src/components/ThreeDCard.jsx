import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RGBELoader } from 'three/examples/jsm/loaders/RGBELoader';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass';
import { RGBShiftShader } from 'three/examples/jsm/shaders/RGBShiftShader';

export default function ThreeDCard({
  src = '/cards/card-rose.png',
  normalSrc = null,
  hdr = null,
  width = 420,
  height = 260,
  enablePost = true,
  bloomStrength = 0.6,
  normalScale = 0.7,
  rgbShiftAmount = 0.0015
}) {
  const mountRef = useRef(null);
  const [glAvailable, setGlAvailable] = useState(true);
  const reducedMotion = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useEffect(() => {
    const isMobile = typeof navigator !== 'undefined' && /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (isMobile) {
      setGlAvailable(false);
      return;
    }

    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (!gl) {
        setGlAvailable(false);
        return;
      }
    } catch (err) {
      setGlAvailable(false);
      return;
    }

    let renderer, scene, camera, mesh, glossMesh, composer, pmremGenerator, envMap;
    let animationId;
    const container = mountRef.current;
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(width, height);
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    container.appendChild(renderer.domElement);

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(35, width / height, 0.1, 1000);
    camera.position.set(0, 0, 6);

    const ambient = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambient);
    const dir = new THREE.DirectionalLight(0xffffff, 0.8);
    dir.position.set(5, 5, 10);
    scene.add(dir);

    pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();

    const loader = new THREE.TextureLoader();
    loader.setCrossOrigin('anonymous');

    const loadEnv = async () => {
      if (!hdr) return null;
      try {
        const rgbeLoader = new RGBELoader();
        const hdrTex = await new Promise((resolve, reject) => {
          rgbeLoader.load(hdr, resolve, undefined, reject);
        });
        hdrTex.mapping = THREE.EquirectangularReflectionMapping;
        envMap = pmremGenerator.fromEquirectangular(hdrTex).texture;
        scene.environment = envMap;
        hdrTex.dispose();
        return envMap;
      } catch (err) {
        return null;
      }
    };

    const setup = async () => {
      await loadEnv();
      const [tex, normalTex] = await Promise.all([
        loader.loadAsync(src).catch(() => null),
        normalSrc ? loader.loadAsync(normalSrc).catch(() => null) : null
      ]);
      if (!tex) {
        cleanup();
        return;
      }
      tex.encoding = THREE.sRGBEncoding;
      tex.anisotropy = renderer.capabilities.getMaxAnisotropy();

      const geo = new THREE.PlaneGeometry(4.2, 2.6, 1, 1);
      const mat = new THREE.MeshStandardMaterial({
        map: tex,
        metalness: 0.45,
        roughness: 0.36,
        envMap: envMap || null,
        envMapIntensity: envMap ? 0.9 : 0.7
      });

      if (normalTex) {
        mat.normalMap = normalTex;
        mat.normalScale = new THREE.Vector2(normalScale, normalScale);
      }

      mesh = new THREE.Mesh(geo, mat);
      mesh.rotation.x = THREE.MathUtils.degToRad(-6);
      scene.add(mesh);

      const glossGeo = new THREE.PlaneGeometry(4.22, 2.62, 1, 1);
      const glossMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.08,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide
      });
      glossMesh = new THREE.Mesh(glossGeo, glossMat);
      glossMesh.position.set(0, 0, 0.01);
      glossMesh.rotation.x = THREE.MathUtils.degToRad(-6);
      scene.add(glossMesh);

      let useComposer = enablePost && !reducedMotion;
      if (useComposer) {
        composer = new EffectComposer(renderer);
        composer.addPass(new RenderPass(scene, camera));
        const bloomPass = new UnrealBloomPass(new THREE.Vector2(width, height), bloomStrength, 0.8, 0.1);
        bloomPass.threshold = 0.85;
        bloomPass.radius = 0.6;
        composer.addPass(bloomPass);

        const rgbPass = new ShaderPass(RGBShiftShader);
        rgbPass.uniforms['amount'].value = rgbShiftAmount;
        composer.addPass(rgbPass);
      }

      let mouseX = 0, mouseY = 0;
      function onPointerMove(e) {
        const rect = container.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;
        mouseX = (x - 0.5) * 2;
        mouseY = (y - 0.5) * 2;
      }
      container.addEventListener('pointermove', onPointerMove);

      let t = 0;
      function animate() {
        animationId = requestAnimationFrame(animate);
        t += 0.016;
        if (mesh) {
          mesh.rotation.y += (mouseX * 0.35 - mesh.rotation.y) * 0.08;
          mesh.rotation.x += (THREE.MathUtils.degToRad(-6) + mouseY * 0.15 - mesh.rotation.x) * 0.08;
          if (mat.normalMap) {
            mat.normalScale.set(normalScale, normalScale);
          }
        }
        if (glossMesh) {
          glossMesh.position.x = Math.sin(t * 0.6) * 0.08;
          glossMesh.position.y = Math.cos(t * 0.4) * 0.05;
        }

        if (composer) composer.render();
        else renderer.render(scene, camera);
      }
      animate();

      function onResize() {
        const rect = container.getBoundingClientRect();
        const w = Math.max(1, rect.width);
        const h = Math.max(1, rect.height);
        renderer.setSize(w, h, false);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        if (composer) composer.setSize(w, h);
      }
      window.addEventListener('resize', onResize);

      cleanup = () => {
        cancelAnimationFrame(animationId);
        window.removeEventListener('resize', onResize);
        container.removeChild(renderer.domElement);
        if (composer) composer.dispose();
        if (mesh) {
          mesh.geometry.dispose();
          if (Array.isArray(mesh.material)) mesh.material.forEach(m => m.dispose && m.dispose());
          else mesh.material.dispose();
        }
        if (envMap) envMap.dispose();
        if (pmremGenerator) pmremGenerator.dispose();
        renderer.dispose();
      };
    };

    let cleanup = () => {};
    setup().catch(() => cleanup());

    return () => {
      try { cleanup(); } catch (e) {}
    };
  }, [src, normalSrc, hdr, width, height, enablePost, bloomStrength, normalScale, rgbShiftAmount, reducedMotion]);

  const placeholderStyle = {
    width: `${width}px`,
    height: `${height}px`,
    borderRadius: 12,
    overflow: 'hidden',
    boxShadow: '0 30px 80px rgba(2,6,23,0.6)',
    background: 'linear-gradient(180deg,#0b0f18,#020406)'
  };

  if (!glAvailable) {
    return (
      <div style={placeholderStyle}>
        <img src={src} alt="Card" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
      </div>
    );
  }

  return <div ref={mountRef} style={placeholderStyle} aria-hidden="true" />;
}