import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { fetchCsrfToken } from '../utils/api';
import ThreeDCard from '../components/ThreeDCard';
import '../styles/luxury.css';

export default function AdminAssets() {
  const [file, setFile] = useState(null);
  const [normal, setNormal] = useState(null);
  const [name, setName] = useState('');
  const [variant, setVariant] = useState('');
  const [assets, setAssets] = useState([]);
  const [csrfToken, setCsrfToken] = useState('');
  const [previewAsset, setPreviewAsset] = useState(null);
  const [bloom, setBloom] = useState(0.6);
  const [normalScale, setNormalScale] = useState(0.7);
  const [rgbShift, setRgbShift] = useState(0.0015);
  const [versions, setVersions] = useState([]);
  const apiBase = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';

  useEffect(() => {
    fetchCsrfToken(apiBase).then(setCsrfToken).catch(() => setCsrfToken(''));
    load();
  }, []);

  async function load() {
    const res = await axios.get(`${apiBase}/assets`);
    setAssets(res.data.assets || []);
  }

  async function upload(e) {
    e.preventDefault();
    if (!file) return alert('Please select a file');
    const form = new FormData();
    form.append('file', file);
    if (normal) form.append('normal', normal);
    if (name) form.append('name', name);
    if (variant) form.append('variant', variant);
    try {
      await axios.post(`${apiBase}/assets/upload`, form, {
        withCredentials: true,
        headers: { 'X-CSRF-Token': csrfToken, 'Content-Type': 'multipart/form-data' }
      });
      alert('Uploaded');
      setFile(null); setNormal(null); setName(''); setVariant('');
      load();
    } catch (err) {
      alert('Upload failed: ' + (err.response?.data?.message || err.message));
    }
  }

  async function preview(a) {
    try {
      const res = await axios.get(`${apiBase}/assets/${a.id}/presign`);
      setPreviewAsset({ ...a, textureUrl: res.data.textureUrl, normalUrl: res.data.normalUrl });
      // load versions
      const vRes = await axios.get(`${apiBase}/assets/${a.id}/versions`, { withCredentials: true, headers: { 'X-CSRF-Token': csrfToken } });
      setVersions(vRes.data.versions || []);
    } catch (err) {
      alert('Preview failed: ' + (err.response?.data?.message || err.message));
    }
  }

  async function createVersion(a) {
    const f = prompt('Paste presigned texture URL to use (or leave empty to upload new file via the form):');
    if (!f) {
      // prompt admin to use the upload form with asset id; we can also support uploading to /:id/version
      return alert('To create a version with a new file, use the "Create Version" uploader under the asset (coming soon).');
    }
  }

  async function rollback(assetId, versionId) {
    if (!confirm('Rollback to this version? This will update the current asset and create a new version entry.')) return;
    try {
      await axios.post(`${apiBase}/assets/${assetId}/versions/${versionId}/rollback`, {}, { withCredentials: true, headers: { 'X-CSRF-Token': csrfToken } });
      alert('Rollback complete');
      load();
    } catch (err) {
      alert('Rollback failed: ' + (err.response?.data?.message || err.message));
    }
  }

  return (
    <div style={{ padding: 24 }}>
      <h2>Admin — Upload Card Asset / Versions</h2>
      <form onSubmit={upload}>
        <div style={{ marginBottom: 8 }}>
          <label>Texture (PNG/JPG/WebP)</label><br />
          <input type="file" accept="image/*" onChange={e => setFile(e.target.files?.[0] || null)} />
        </div>
        <div style={{ marginBottom: 8 }}>
          <label>Normal map (optional)</label><br />
          <input type="file" accept="image/*" onChange={e => setNormal(e.target.files?.[0] || null)} />
        </div>
        <div style={{ marginBottom: 8 }}>
          <label>Name</label><br />
          <input value={name} onChange={e => setName(e.target.value)} />
        </div>
        <div style={{ marginBottom: 8 }}>
          <label>Variant (e.g., rose, silver, back)</label><br />
          <input value={variant} onChange={e => setVariant(e.target.value)} />
        </div>
        <button type="submit">Upload</button>
      </form>

      <h3 style={{ marginTop: 24 }}>Existing assets</h3>
      <ul>
        {assets.map(a => (
          <li key={a.id} style={{ marginBottom: 8 }}>
            {a.name} {a.variant ? `(${a.variant})` : ''} — <button onClick={() => preview(a)}>Preview & Versions</button>
            <a style={{ marginLeft: 8 }} href={`/assets/${a.originalPath ? a.originalPath.split('/').pop() : ''}`} target="_blank" rel="noreferrer">original</a>
          </li>
        ))}
      </ul>

      {previewAsset && (
        <div style={{ marginTop: 18 }}>
          <h3>Preview: {previewAsset.name}</h3>
          <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
            <div>
              <ThreeDCard
                src={previewAsset.textureUrl}
                normalSrc={previewAsset.normalUrl}
                enablePost={true}
                bloomStrength={bloom}
                normalScale={normalScale}
                rgbShiftAmount={rgbShift}
                width={560}
                height={360}
              />
            </div>
            <div style={{ minWidth: 320 }}>
              <div style={{ marginBottom: 12 }}>
                <label>Bloom Strength: {bloom}</label>
                <input type="range" min="0" max="2" step="0.05" value={bloom} onChange={e => setBloom(Number(e.target.value))} />
              </div>
              <div style={{ marginBottom: 12 }}>
                <label>Normal Scale: {normalScale}</label>
                <input type="range" min="0" max="2" step="0.05" value={normalScale} onChange={e => setNormalScale(Number(e.target.value))} />
              </div>
              <div style={{ marginBottom: 12 }}>
                <label>RGB Shift: {rgbShift}</label>
                <input type="range" min="0" max="0.01" step="0.0005" value={rgbShift} onChange={e => setRgbShift(Number(e.target.value))} />
              </div>

              <h4 style={{ marginTop: 18 }}>Versions</h4>
              <ul>
                {versions.map(v => (
                  <li key={v.id} style={{ marginBottom: 8 }}>
                    v{v.versionNumber} — {new Date(v.createdAt).toLocaleString()} by {v.createdBy?.email || 'system'}
                    <div style={{ marginTop: 6 }}>
                      <a href={v.texturePath} target="_blank" rel="noreferrer">texture</a>
                      {v.normalPath && <> • <a href={v.normalPath} target="_blank" rel="noreferrer">normal</a></>}
                      <button style={{ marginLeft: 8 }} onClick={() => rollback(previewAsset.id, v.id)}>Rollback to this</button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}